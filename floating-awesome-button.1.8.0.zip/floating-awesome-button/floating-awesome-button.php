<?php
/*
 * Plugin Name:       Floating Awesome Button
 * Plugin URI:        https://artistudio.xyz
 * Description:       Floating Awesome Button (FAB): Elevate engagement with customizable action buttons. Showcase modals,shortcodes, widgets & links effortlessly.
 * Version:           1.8.0
 * Author:            Artistudio
 * Author URI:        https://brain.artistudio.xyz/knowledge/WordPress-floating-awesome-button
 * License:           GPL-3.0
 * License URI:       http://www.gnu.org/licenses/gpl-3.0.txt
 *
 * Text Domain: floating-awesome-button
 * Domain Path: /languages/
 *
 * SOFTWARE LICENSE INFORMATION
 *
 * Copyright 2021 Artistudio, all rights reserved.
 *
 * For detailed information regarding to the licensing of
 * this software, please review the license.txt
*/

! defined( 'WPINC ' ) || die;

/** Load Composer Vendor */
require plugin_dir_path( __FILE__ ) . 'vendor/autoload.php';

/** Load Freemius */
require plugin_dir_path( __FILE__ ) . 'freemius.php';

/** Load Helper */
if ( file_exists( plugin_dir_path( __FILE__ ) . 'helper.php' ) ) {
    require plugin_dir_path( __FILE__ ) . 'helper.php';
}

/** Initiate Plugin */
$fab = new Fab\Plugin();
$fab->run();

/** Activation Hook */
register_activation_hook( __FILE__, array( $fab, 'activate' ) );

/** Uninstall Hook */
register_uninstall_hook( __FILE__, 'uninstall_fab_plugin' );
function uninstall_fab_plugin() {
    delete_option( 'fab_config' ); }
