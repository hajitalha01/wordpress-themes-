<?php

namespace Fab\Controller;

! defined( 'WPINC ' ) or die;

/**
 * Plugin hooks in a backend
 *setComponent
 *
 * @package    Fab
 * @subpackage Fab/Controller
 */

use Fab\View;
use Fab\Wordpress\Hook\Action;

class Notice extends Base {

    /**
     * Admin constructor
     *
     * @return void
     * @var    object   $plugin     Plugin configuration
     * @pattern prototype
     */
    public function __construct( $plugin ) {
        parent::__construct( $plugin );

        /** Handle notice promo premium upgrade  */
        $action = new Action();
        $action->setComponent( $this );
        $action->setHook( 'admin_notices' );
        $action->setCallback( 'fab_show_admin_upgrade_notice' );
        $action->setAcceptedArgs( 0 );
        $action->setDescription( 'Admin notice for promo premium upgrade' );
        $action->setFeature( $plugin->getFeatures()['core_backend'] );
        $this->hooks[] = $action;

        // /** Handle dismiss notice ajax */
        $action = clone $action;
        $action->setHook( 'wp_ajax_fs_dismiss_notice_action_floating-awesome-button' );
        $action->setCallback( 'dismiss_notice_ajax_callback' );
        $action->setDescription( 'Handle plugin upgrade' );
        $action->setPriority( 1 );
        $action->setFeature( $plugin->getFeatures()['core_backend'] );
        $this->hooks[] = $action;

        /** Handle freemium notice */
        fab_freemius()->add_filter( 'show_admin_notice', array($this, 'fs_show_admin_notice'), 10, 2 );
    }


    /**
     * Override freemium notice.
     *
     * @return bool false to force disable default freemium notice.
     */
    public function fs_show_admin_notice( $show, $msg ) {

        add_action( 'admin_footer', array( 'FS_Admin_Notice_Manager', '_add_sticky_dismiss_javascript' ) );
        View::RenderStatic( 'Backend.admin-notice', $msg );

        return false;
    }

    /**
     * Show admin upgrade notice.
     *
     * @return void
     */
    public function fab_show_admin_upgrade_notice() {
        if ( function_exists( 'current_user_can' ) &&
                ! current_user_can( 'manage_options' )
        ) {
            // Only show messages to admins.
            return;
        }

        // Check if the user is on a premium plan.
        if ( $this->Helper->isPremiumPlan() ){
            return;
        }

        $screen = get_current_screen();

        // Check if the admin notice promo upgrade option is set and if the current screen is not the FAB settings page.
        if ( get_option('fs_fab_admin_notice_promo_upgrade') && $screen->id !== 'settings_page_floating-awesome-button-setting' ){
            return;
        }

        // Determine if the notice should be dismissible.
        $dismissible = $screen->id !== 'settings_page_floating-awesome-button-setting';

        // Prepare the data for the admin notice.
        $data = array(
            'message' => 'You\'re currently on our free plan. Elevate your experience by upgrading now and unlock exclusive features and benefits!',
            'dismissible' => $dismissible,
            'sticky' => true,
            'manager_id' => 'floating-awesome-button',
            'id' => 'fab_upgrade_premium',
            'plugin' => 'Floating Awesome Button',
            'type' => 'promotion',
            'buttons' => array(
                array(
                    'message' => 'Click here to upgrade →',
                    'url' => $this->Helper->getUpgradeURL(),
                    'classes' => 'button button-primary'
                ),
            )
        );

        // Add the JavaScript for making the notice sticky and dismissible.
        add_action( 'admin_footer', array( 'FS_Admin_Notice_Manager', '_add_sticky_dismiss_javascript' ) );

        View::RenderStatic( 'Backend.admin-notice', $data );
    }

    /**
     * Ajax callback for dismissing the notice.
     */
    public function dismiss_notice_ajax_callback() {

        if(isset($_POST['message_id']) && $_POST['message_id'] === 'fab_upgrade_premium'){
            update_option('fs_fab_admin_notice_promo_upgrade', true);
        }

    }

}
