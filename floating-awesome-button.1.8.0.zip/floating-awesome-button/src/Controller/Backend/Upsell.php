<?php

namespace Fab\Controller;

! defined( 'WPINC ' ) or die;

/**
 * Plugin hooks in a backend
 *setComponent
 *
 * @package    Fab
 * @subpackage Fab/Controller
 */

use Fab\View;
use Fab\Wordpress\Hook\Action;

class Upsell extends Base {

    private $_plugin;

    /**
     * Admin constructor
     *
     * @return void
     * @var    object   $plugin     Plugin configuration
     * @pattern prototype
     */
    public function __construct( $plugin ) {
        $this->_plugin = $plugin;

        parent::__construct( $plugin );

        $action = new Action();
        $action->setComponent( $this );
        $action->setHook( 'admin_enqueue_scripts' );
        $action->setCallback( 'backend_enequeue_metabox_trigger' );
        $action->setAcceptedArgs( 1 );
        $action->setMandatory( true );
        $action->setDescription( 'Enqueue backend metabox trigger' );
        $action->setFeature( $plugin->getFeatures()['core_backend'] );
        $this->hooks[] = $action;
    }

    /**
     * Eneque scripts @backend
     *
     * @return  void
     * @var     array   $hook_suffix     The current admin page
     */
    public function backend_enequeue_metabox_trigger( $hook_suffix ) {
        global $post;
        $screen = $this->WP->getScreen();
        $allowedPage = ['post.php', 'post-new.php'];
        if ( !isset( $post->post_type ) || $post->post_type !== 'fab' || !in_array($screen->pagenow, $allowedPage) ) {
            return;
        }

        if ( $this->Helper->isPremiumPlan() ) {
            return;
        }

        $metabox_ids = $this->_plugin->getFeatures()['upsell']->getParams();

        /** Add Inline Script */
        $this->WP->wp_localize_script(
            'fab-local',
            'FAB_METABOX_UPSELL',
            array(
                'upsells' => $metabox_ids,
                'logo' => json_decode( FAB_PATH )->plugin_url . '/assets/img/icon.png',
                'title' => __( 'Upgrade To Get Floating Awesome Button Premium Features', 'floating-awesome-button' ),
                'content' => sprintf(
                    '<p>%s</p><p>%s</p><p>%s</p>',
                    __( 'Upgrade to our Premium version to gain full control over when and where your Floating Awesome Button appears.', 'floating-awesome-button' ),
                    __( 'You can create rules based to precisely target where your button appears. Additionally, choose from advanced triggers like Adblock, Exit Intent, Time Delay, or customize your own trigger behavior.', 'floating-awesome-button' ),
                    __( 'Upgrade today to enhance engagement and maximize conversions with targeted button placement!', 'floating-awesome-button' )
                ),
                'button' => '<a target="_blank" href="' . esc_url( $this->Helper->getUpgradeURL() ) . '" class="button-class">' . __( 'Upgrade Now →', 'floating-awesome-button' ) . '</a>'
            )
        );

        $this->WP->wp_enqueue_script( 'upsell-component', 'build/components/upsell/bundle.js', array(), '', true );
    }

}
