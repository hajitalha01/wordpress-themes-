<?php

namespace Fab\Controller;

! defined( 'WPINC ' ) or die;

/**
 * Initiate plugins
 *
 * @package    Fab
 * @subpackage Fab/Controller
 */

use Fab\View;
use Fab\Helper\FABItem;
use Fab\Feature\Design;
use Fab\Feature\Modal;
use Fab\Wordpress\Hook\Action;
use Fab\Wordpress\MetaBox;

class MetaboxDesign extends Base {

    /**
     * Admin constructor
     *
     * @return void
     * @var    object   $plugin     Plugin configuration
     * @pattern prototype
     */
    public function __construct( $plugin ) {
        parent::__construct( $plugin );

        /** @backend - Eneque scripts */
        $action = new Action();
        $action->setComponent( $this );
        $action->setHook( 'admin_enqueue_scripts' );
        $action->setCallback( 'backend_enequeue_metabox_design' );
        $action->setAcceptedArgs( 1 );
        $action->setMandatory( true );
        $action->setDescription( 'Enqueue backend metabox design' );
        $action->setFeature( $plugin->getFeatures()['core_backend'] );
        $this->hooks[] = $action;

        /** @backend - Add Designs metabox to Fab CPT */
        $action = new Action();
        $action->setComponent( $this );
        $action->setHook( 'add_meta_boxes' );
        $action->setCallback( 'metabox_design' );
        $action->setMandatory( false );
        $action->setDescription( 'Add Design metabox to Fab CPT' );
        $action->setFeature( $plugin->getFeatures()['core_backend'] );
        $action->setPremium( false );
        $this->hooks[] = $action;
    }

    /**
     * Eneque scripts @backend
     *
     * @return  void
     * @var     array   $hook_suffix     The current admin page
     */
    public function backend_enequeue_metabox_design( $hook_suffix ) {
        /** Grab Data */
        global $post;
        $screen = $this->WP->getScreen();
        $allowedPage = ['post.php', 'post-new.php'];
        if ( !isset( $post->post_type ) || $post->post_type !== 'fab' || !in_array($screen->pagenow, $allowedPage) ) {
            return;
        }

        /** Grab Data */
        $fab = new FABItem( $post->ID );
        $fab = $fab->getVars();

        /** Add Inline Script */
        $this->WP->wp_localize_script( 'fab-local', 'FAB_METABOX_DESIGN', array(
            'defaultOptions' => [
                'size' => array( 'type' => Design::$size['type'] ),
                'theme' => Modal::$theme,
                'layout' => Modal::$layout,
                'template' => Design::$template,
            ],
            'data' => compact('fab'),
            'labels' => 
                array( 
                    'button' =>  
                        array(
                            'color' => array(
                                'text' => __( 'Color', 'floating-awesome-button' ),
                                'tooltip' => __('Select the color for the button. This color will be applied to the button background.', 'floating-awesome-button'),
                            ),
                            'shape' => array(
                                'text' => __( 'Shape', 'floating-awesome-button' ),
                                'tooltip' => __('Choose the shape of the button. Options include rounded, square, or custom shapes.', 'floating-awesome-button'),
                                'info' => sprintf(
                                    __('Please refer to %s to see the shape', 'floating-awesome-button'),'<code><a href="https://bennettfeely.com/clippy/" target="_blank">Clippy</a></code>'
                                ),
                            ),
                            'responsive' => array(
                                'text' => __( 'Show In', 'floating-awesome-button' ),
                                'tooltip' => __('Determine where the button should be visible. Options include mobile, tablet, and desktop views.', 'floating-awesome-button'),
                                'switchs' => array(
                                    'mobile' => __( 'Mobile', 'floating-awesome-button' ),
                                    'tablet' => __( 'Tablet', 'floating-awesome-button' ),
                                    'desktop' => __( 'Desktop', 'floating-awesome-button' ),
                                )
                            ),
                            'standalone' => array(
                                'text' => __( 'Standalone', 'floating-awesome-button' ),
                                'tooltip' => __('Enable this option to separate the button from other groups, making it an individual element.', 'floating-awesome-button'),
                                'info' => __( 'Seperates button from groups', 'floating-awesome-button' ),
                                'enable' => __( 'Enable', 'floating-awesome-button' ),
                            ),
                            'hotkey' => array(
                                'text' => __( 'Hotkey', 'floating-awesome-button' ),
                                'tooltip' => __('Configure hotkeys for the button.', 'floating-awesome-button'),
                                'info' => sprintf(
                                    __('Please refer to %s to see supported hotkey', 'floating-awesome-button'),'<code><a href="https://rawgit.com/jeresig/jquery.hotkeys/master/test-static-01.html" target="_blank">jQuery Hotkeys</a></code>'
                                ),
                            ),
                            'icon' => array(
                                'text' => __( 'Icon', 'floating-awesome-button' ),
                                'tooltip' => __('Select the icon for the button.', 'floating-awesome-button'),
                                'info' => __( 'Icon Configuration', 'floating-awesome-button' ),
                                'class' => __( 'Class', 'floating-awesome-button' ),
                                'color' => __( 'Color', 'floating-awesome-button' ),
                                'tooltip_color' => __('Select the color for the icon.', 'floating-awesome-button'),
                                'picker' => array(
                                    'title' => __('Icon Selector','floating-awesome-button'),
                                    'search_placeholder'  => __('Search icon...','floating-awesome-button'),
                                    'delete' => __('Delete','floating-awesome-button'),
                                    'cancel' => __('Cancel','floating-awesome-button'),
                                    'select' => __('Select','floating-awesome-button'),
                                )
                            ),
                            'tooltip' => array(
                                'text' => __( 'Tooltip', 'floating-awesome-button' ),
                                'always_display' =>  __( 'Always Display', 'floating-awesome-button' ),
                                'tooltip' => __('Choose whether to always display or not', 'floating-awesome-button'),
                                'info' => __( 'Tooltip Configuration', 'floating-awesome-button' ),
                                'enable' => __( 'Enable', 'floating-awesome-button' ),
                                'font_color' => __( 'Font Color', 'floating-awesome-button' ),
                                'tooltip_font_color' => __('Specify the color for the text button.', 'floating-awesome-button'),
                            ),
                        ), 
                    'modal' => 
                        array(
                            'theme' => array(
                                'text' => __( 'Theme', 'floating-awesome-button' ),
                                'tooltip' => __('Select the theme for the modal.', 'floating-awesome-button'),
                            ),
                            'layout' => array(
                                'text' => __( 'Layout', 'floating-awesome-button' ),
                                'tooltip' => __('Choose the layout for the modal content. This includes how elements are arranged inside the modal.', 'floating-awesome-button'),
                            ),
                            'size' => array(
                                'text' => __( 'Size', 'floating-awesome-button' ),
                                'tooltip' => __('Select the predefined size of the modal, such as small, medium, or large.', 'floating-awesome-button'),
                            ),
                            'custom_size' => array(
                                'text' => __( 'Custom Size', 'floating-awesome-button' ),
                                'tooltip' => __('Specify a custom size for the modal. You can use units like %, px, or em.', 'floating-awesome-button'),
                                'placeholder' => __('Custom Size %, px, em', 'floating-awesome-button'),
                            ),
                            'navigation' => array(
                                'text' => __( 'Navigation', 'floating-awesome-button' ),
                                'tooltip' => __('Configure the navigation elements within the modal.', 'floating-awesome-button'),
                            ),
                            'background_color' => array(
                                'text' => __( 'Background Color', 'floating-awesome-button' ),
                                'tooltip' => __('Set the background color of the modal.', 'floating-awesome-button'),
                            ),
                            'animation' => array(
                                'text' => __( 'Animation', 'floating-awesome-button' ),
                                'info' => sprintf(
                                    __( 'To see animation reference you can go to <code><a href="%s" target="_blank">Animate.css</a></code>', 'floating-awesome-button' ),
                                    'https://daneden.github.io/animate.css/'
                                ),
                                'in' => array(
                                    'text' => __( 'In', 'floating-awesome-button' ),
                                    'tooltip'  => __('Select the animation for how the modal appears.', 'floating-awesome-button'),
                                ),
                                'out' => array(
                                    'text' => __( 'Out', 'floating-awesome-button' ),
                                    'tooltip'  => __('Select the animation for how the modal disappears.', 'floating-awesome-button'),
                                ),
                            ),
                            'overlay' => array(
                                'text' => __( 'Overlay', 'floating-awesome-button' ),
                                'info' =>  __( 'Modal Overlay', 'floating-awesome-button' ),
                                'background_color' => array(
                                    'text' => __( 'Background Color', 'floating-awesome-button' ),
                                    'tooltip'  => __('Set the background color of the overlay that appears behind the modal.', 'floating-awesome-button'),
                                ),
                                'opacity' => array(
                                    'text' => __( 'Opacity', 'floating-awesome-button' ),
                                    'tooltip'  => __('Adjust the transparency of the overlay background.', 'floating-awesome-button'),
                                ),
                            ),
                            'spacing' => array(
                                'text' => __( 'Content Spacing', 'floating-awesome-button' ),
                                'info' =>  __( 'Modal Overlay', 'floating-awesome-button' ),
                                'padding' => array(
                                    'text' => __( 'Padding', 'floating-awesome-button' ),
                                    'tooltip'  => __('Set the padding inside the modal content area.', 'floating-awesome-button'),
                                ),
                                'margin' => array(
                                    'text' => __( 'Margin', 'floating-awesome-button' ),
                                    'tooltip'  => __('Set the margin around the modal content.', 'floating-awesome-button'),
                                ),
                            ),
                            'no_modal' => array(
                                'text' => __( 'None modal/popup type action button!', 'floating-awesome-button' ),
                                'info' =>  __( 'Please change the type to modal/popup to access the setting.', 'floating-awesome-button' ),
                            ),
                        ), 
                ),
            )
        );

        /** Enqueue */
        $this->WP->wp_enqueue_script( 'fab-design', 'build/js/backend/metabox-design.min.js', array(), '', true );

        /** Load Component */
        $component = 'metabox-design';
        $this->WP->wp_enqueue_style( sprintf('%s-component', $component), sprintf('build/components/%s/bundle.css', $component) );
        $this->WP->wp_enqueue_script(sprintf('%s-component', $component), sprintf('build/components/%s/bundle.js', $component), array(), '1.0', true);
    }

    /**
     * Register metabox designs on custom post type Fab
     *
     * @return      void
     */
    public function metabox_design() {
        $metabox = new MetaBox();
        $metabox->setScreen( 'fab' );
        $metabox->setId( 'fab-metabox-design' );
        $metabox->setTitle( 'Design' );
        $metabox->setCallback( array( $this, 'metabox_design_callback' ) );
        $metabox->setCallbackArgs( array( 'is_display' => false ) );
        $metabox->build();
    }


    /**
     * Metabox Design set view template
     *
     * @return      string              Html template string from view View/Template/backend/metabox_design.php
     * @param       object $post      global $post object
     */
    public function metabox_design_callback() {
        View::RenderStatic('Backend.Metabox.design');
    }

}