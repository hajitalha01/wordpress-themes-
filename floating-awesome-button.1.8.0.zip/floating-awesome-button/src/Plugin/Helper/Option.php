<?php

namespace Fab\Helper;

!defined( 'WPINC ' ) or die;

/**
 * Helper library for Fab plugins
 *
 * @package    Fab
 * @subpackage Fab\Includes
 */

trait Option {

    /** Features Hooks Lists */
    public function FeatureHooksLists($features, $hooks, $options = array()){
        $featureHooks = array();
        foreach($features as $slug => $feature){
            if(!isset( $hooks[ $slug ] )) { continue; } // Unlists feature with no hooks.
            $featureHooks[$slug] = $feature->getVars();
            $featureHooks[$slug]['hooksCount'] = count($hooks[$slug]);
            $featureHooks[$slug]['hooks'] = $hooks[$slug];
            $featureHooks[$slug]['activeHooks'] = 0;
            foreach($featureHooks[$slug]['hooks'] as $key => &$hook){
                $tmp = array();
                /** Reconstruct Class */
                $tmp['namespace'] = ( new \ReflectionClass( $hook->getComponent() ) )->getNamespaceName();
                $tmp['name'] = ( new \ReflectionClass( $hook->getComponent() ) )->getShortName();
                $tmp['namespaceKey'] = str_replace( '\\', '_', strtolower( $tmp['namespace'] ) );
                $tmp['hookName'] = preg_replace( '/[^A-Za-z0-9_]/', '', strtolower( $hook->getHook() ) );
                $tmp['callbackName'] = preg_replace( '/[^A-Za-z0-9_]/', '', strtolower( $hook->getCallback() ) );
                $key = sprintf( 'hooks_%s_%s_%s_%s', $tmp['namespaceKey'], strtolower( $tmp['name'] ), $tmp['hookName'], $tmp['callbackName'] );
                $tmp['key'] = $key;
                $tmp['status'] = ( isset( $options->fab_hooks->$key ) ) ? $options->fab_hooks->$key : $hook->isStatus(); // Option Exists
                $tmp['status'] = ( $tmp['status']==='true' || $tmp['status']=='1' ) ? true : false; // Grab option status
                if ( $tmp['status'] == true || $hook->isMandatory() ) { $featureHooks[$slug]['activeHooks']++; }
                $tmp['mandatory'] = $hook->isMandatory();
                /** Hook Info */
                $tmp['hookName'] = $hook->getHook();
                $tmp['callbackName'] = $hook->getCallback();
                $tmp['description'] = $hook->getDescription();
                $hook = $tmp;
            }
        }

        return $featureHooks;
    }

    /** Array Merge Recursive */
    public function ArrayMergeRecursive($array1, $array2) {
        $merged = (array) $array1; // Cast both to arrays to handle stdClass objects
        foreach ((array) $array2 as $key => $value) {
            // If both elements are arrays or objects, recursively merge them
            if (is_array($value) || is_object($value)) {
                if (isset($merged[$key]) && (is_array($merged[$key]) || is_object($merged[$key]))) {
                    $merged[$key] = $this->ArrayMergeRecursive($merged[$key], $value);
                } else {
                    $merged[$key] = $value;
                }
            } 
            // For numeric keys, append value if not already in the array
            else if (is_numeric($key)) {
                if (!in_array($value, $merged)) {
                    $merged[] = $value;
                }
            } 
            // For non-numeric keys, overwrite or set the value
            else {
                $merged[$key] = $value;
            }
        }
    
        // Return the merged array, casting back to object if necessary
        return is_object($array1) ? (object) $merged : $merged;
    }

    /** Transform Boolean Value */
    public function transformBooleanValue($data){
        if(is_array($data)){
            foreach($data as $key => &$value){
                if( is_array($value) ){ $value = $this->transformBooleanValue( $value ); }
                else { $value = ($value==='true' || $value==='1') ? 1 : 0; }
            }
        } else { $data = ($data==='true' || $data ==='1') ? 1 : 0; }
        return $data;
    }

}
